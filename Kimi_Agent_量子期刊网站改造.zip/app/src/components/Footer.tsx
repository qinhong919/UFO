import { Link } from "react-router";
import { BookOpen } from "lucide-react";

const quickLinks = [
  { label: "前沿与方法", path: "/frontiers" },
  { label: "传统与经验", path: "/tradition" },
  { label: "田野与档案", path: "/field-archive" },
  { label: "对话与争鸣", path: "/dialogue" },
  { label: "征稿", path: "/submission" },
];

export function Footer() {
  return (
    <footer
      className="no-print"
      style={{
        backgroundColor: "var(--paper-dark)",
        borderTop: "1px solid var(--border-color)",
      }}
    >
      <div className="container-journal py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div
                className="w-8 h-8 rounded-sm flex items-center justify-center"
                style={{ backgroundColor: "var(--accent)" }}
              >
                <BookOpen className="w-4 h-4 text-white" />
              </div>
              <div>
                <h3
                  className="text-lg font-bold"
                  style={{ fontFamily: '"Noto Serif SC", serif' }}
                >
                  量子
                </h3>
                <p
                  className="text-xs"
                  style={{
                    fontFamily: '"Cormorant Garamond", serif',
                    color: "var(--muted)",
                  }}
                >
                  Quantum Journal
                </p>
              </div>
            </div>
            <p
              className="text-sm leading-relaxed"
              style={{ color: "var(--ink-light)" }}
            >
              国际超心理与中国传统文化期刊
              <br />
              Vol.01 · 2026.05 · 创刊号
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4
              className="text-caption font-medium mb-4"
              style={{ color: "var(--muted)" }}
            >
              栏目导航
            </h4>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="text-sm transition-colors hover:underline"
                    style={{ color: "var(--ink-light)" }}
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4
              className="text-caption font-medium mb-4"
              style={{ color: "var(--muted)" }}
            >
              联系方式
            </h4>
            <div
              className="text-sm space-y-2"
              style={{ color: "var(--ink-light)" }}
            >
              <p>投稿邮箱：submission@quantum-journal.org</p>
              <p>编辑部：editor@quantum-journal.org</p>
            </div>
            <div className="mt-6">
              <Link
                to="/submission"
                className="inline-flex items-center gap-2 px-4 py-2 text-sm rounded-sm transition-colors"
                style={{
                  backgroundColor: "var(--accent)",
                  color: "white",
                }}
              >
                立即投稿
              </Link>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div
          className="mt-12 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4"
          style={{ borderTop: "1px solid var(--border-color)" }}
        >
          <p className="text-xs" style={{ color: "var(--muted)" }}>
            &copy; 2026 量子 Quantum Journal. 保留所有权利。
          </p>
          <p className="text-xs" style={{ color: "var(--muted)" }}>
            最后更新：2026-05-12
          </p>
        </div>
      </div>
    </footer>
  );
}
