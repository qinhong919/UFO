import { useState } from "react";
import { Link, useLocation } from "react-router";
import { Menu, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const navItems = [
  { label: "目录", path: "/" },
  { label: "前沿与方法", path: "/frontiers" },
  { label: "传统与经验", path: "/tradition" },
  { label: "田野与档案", path: "/field-archive" },
  { label: "对话与争鸣", path: "/dialogue" },
  { label: "征稿", path: "/submission" },
];

export function MobileMenu() {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  return (
    <div className="md:hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="p-2 rounded-md transition-colors"
        aria-label={isOpen ? "关闭菜单" : "打开菜单"}
      >
        {isOpen ? (
          <X className="w-5 h-5" style={{ color: "var(--ink)" }} />
        ) : (
          <Menu className="w-5 h-5" style={{ color: "var(--ink)" }} />
        )}
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 top-16 z-50"
            style={{ backgroundColor: "var(--paper)" }}
          >
            <nav className="flex flex-col items-center justify-center h-full gap-6">
              {navItems.map((item, index) => (
                <motion.div
                  key={item.path}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 + 0.1 }}
                >
                  <Link
                    to={item.path}
                    onClick={() => setIsOpen(false)}
                    className="text-h2 font-serif-display transition-colors"
                    style={{
                      color:
                        location.pathname === item.path
                          ? "var(--accent)"
                          : "var(--ink)",
                    }}
                  >
                    {item.label}
                  </Link>
                </motion.div>
              ))}
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
