import { Link, useLocation } from "react-router";
import { MobileMenu } from "./MobileMenu";

const navItems = [
  { label: "前沿与方法", path: "/frontiers" },
  { label: "传统与经验", path: "/tradition" },
  { label: "田野与档案", path: "/field-archive" },
  { label: "对话与争鸣", path: "/dialogue" },
  { label: "征稿", path: "/submission" },
];

export function Navbar() {
  const location = useLocation();

  return (
    <header
      className="fixed top-0 left-0 right-0 z-50 no-print"
      style={{
        backgroundColor: "rgba(250, 248, 245, 0.95)",
        backdropFilter: "blur(8px)",
        WebkitBackdropFilter: "blur(8px)",
        borderBottom: "1px solid var(--border-color)",
      }}
    >
      <div className="container-journal">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3 shrink-0">
            <div
              className="w-8 h-8 rounded-sm flex items-center justify-center"
              style={{ backgroundColor: "var(--accent)" }}
            >
              <span
                className="text-white font-serif-display text-sm font-bold"
                style={{ fontFamily: '"Noto Serif SC", serif' }}
              >
                量
              </span>
            </div>
            <div className="flex flex-col leading-tight">
              <span
                className="text-sm font-bold tracking-wider"
                style={{
                  fontFamily: '"Noto Serif SC", serif',
                  color: "var(--ink)",
                }}
              >
                量子
              </span>
              <span
                className="text-xs"
                style={{
                  fontFamily: '"Cormorant Garamond", serif',
                  color: "var(--muted)",
                }}
              >
                Quantum Journal
              </span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-1">
            <Link
              to="/"
              className="px-3 py-2 text-sm rounded transition-colors"
              style={{
                color: location.pathname === "/" ? "var(--accent)" : "var(--ink-light)",
                backgroundColor: location.pathname === "/" ? "var(--accent-light)" : "transparent",
              }}
            >
              目录
            </Link>
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className="px-3 py-2 text-sm rounded transition-colors relative group"
                style={{
                  color:
                    location.pathname === item.path
                      ? "var(--accent)"
                      : "var(--ink-light)",
                  backgroundColor:
                    location.pathname === item.path
                      ? "var(--accent-light)"
                      : "transparent",
                }}
              >
                {item.label}
                <span
                  className="absolute bottom-1 left-3 right-3 h-px transition-transform origin-left duration-250"
                  style={{
                    backgroundColor: "var(--accent)",
                    transform: location.pathname === item.path ? "scaleX(1)" : "scaleX(0)",
                  }}
                />
              </Link>
            ))}
          </nav>

          {/* Mobile Menu */}
          <MobileMenu />
        </div>
      </div>
    </header>
  );
}
