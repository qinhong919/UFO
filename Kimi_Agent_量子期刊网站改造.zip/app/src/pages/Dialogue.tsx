import { Link } from "react-router";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { ScrollReveal } from "@/components/ScrollReveal";
import { motion } from "framer-motion";

const types = [
  {
    label: "事实之争",
    desc: "关于发生了什么的争论。可以用证据解决。关键是拿出可靠的来源和数据。",
  },
  {
    label: "价值之争",
    desc: "关于什么更重要的争论。不能用证据解决，但可以澄清各自的价值观前提。",
  },
  {
    label: "策略之争",
    desc: "关于怎么做的争论。可以分析各自的优劣条件和预期后果来做判断。",
  },
];

const cards = [
  {
    label: "拆解",
    title: "把争论拆成类型",
    description:
      "对方在反驳什么？是事实、价值还是策略？不同类型用不同方法回应。事实用证据，价值澄清前提，策略分析后果。",
  },
  {
    label: "留余地",
    title: "留余地，但不放弃判断",
    description:
      "好的争论者会承认不确定性。但承认不确定不等于没有立场。说清楚你的判断基于什么、保留哪些疑虑。",
  },
  {
    label: "追逻辑",
    title: "追对方的逻辑链",
    description:
      "不要只反驳结论，要看对方是怎么从前提推到结论的。逻辑链上的哪一环 weakest，就在那里展开讨论。",
  },
];

export function Dialogue() {
  return (
    <div className="pt-24 md:pt-32">
      <div className="container-journal">
        {/* Hero */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-16"
        >
          <div className="accent-line mb-6" />
          <h1
            className="text-h1 mb-4"
            style={{
              fontFamily: '"Noto Serif SC", serif',
              color: "var(--ink)",
              wordBreak: "keep-all",
            }}
          >
            对话与争鸣
          </h1>
          <p
            className="text-h3 mb-8 font-sans-body font-normal"
            style={{ color: "var(--ink-light)", wordBreak: "keep-all" }}
          >
            争论不是吵架。好的争论拆类型、追逻辑、留余地。差的争论扣帽子、转话题、比嗓门。
          </p>
          <p className="text-body max-w-2xl" style={{ color: "var(--ink-light)" }}>
            争论要拆类型：事实、价值、策略。留余地，但不放弃判断。
          </p>
        </motion.div>

        {/* Types */}
        <ScrollReveal>
          <div className="mb-16">
            <h2
              className="text-h3 mb-8"
              style={{
                fontFamily: '"Noto Serif SC", serif',
                color: "var(--ink)",
              }}
            >
              三种争论类型
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {types.map((t, i) => (
                <ScrollReveal key={t.label} delay={i * 0.1}>
                  <div
                    className="p-6 rounded-sm"
                    style={{
                      backgroundColor: "var(--accent-light)",
                      border: "1px solid rgba(193, 91, 63, 0.15)",
                    }}
                  >
                    <h3
                      className="text-h3 mb-3"
                      style={{
                        fontFamily: '"Noto Serif SC", serif',
                        color: "var(--accent)",
                      }}
                    >
                      {t.label}
                    </h3>
                    <p
                      className="text-small leading-relaxed"
                      style={{ color: "var(--ink-light)" }}
                    >
                      {t.desc}
                    </p>
                  </div>
                </ScrollReveal>
              ))}
            </div>
          </div>
        </ScrollReveal>

        {/* Cards */}
        <ScrollReveal>
          <div className="mb-16">
            <div className="flex items-baseline justify-between mb-8">
              <h2
                className="text-h3"
                style={{
                  fontFamily: '"Noto Serif SC", serif',
                  color: "var(--ink)",
                }}
              >
                争论方法
              </h2>
              <span
                className="text-caption"
                style={{ color: "var(--muted)" }}
              >
                三个原则
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {cards.map((card, i) => (
                <ScrollReveal key={card.label} delay={i * 0.1}>
                  <div className="card-journal">
                    <span
                      className="text-caption font-medium tracking-widest block mb-3"
                      style={{ color: "var(--accent)" }}
                    >
                      {card.label}
                    </span>
                    <h3
                      className="text-h3 mb-3"
                      style={{
                        fontFamily: '"Noto Serif SC", serif',
                        color: "var(--ink)",
                      }}
                    >
                      {card.title}
                    </h3>
                    <p
                      className="text-small leading-relaxed"
                      style={{ color: "var(--ink-light)" }}
                    >
                      {card.description}
                    </p>
                  </div>
                </ScrollReveal>
              ))}
            </div>
          </div>
        </ScrollReveal>

        {/* Bottom Navigation */}
        <ScrollReveal>
          <div
            className="flex items-center justify-between py-8 mb-8"
            style={{ borderTop: "1px solid var(--border-color)" }}
          >
            <Link
              to="/field-archive"
              className="flex items-center gap-2 text-sm transition-colors"
              style={{ color: "var(--ink-light)" }}
            >
              <ArrowLeft className="w-4 h-4" />
              上一栏目：田野与档案
            </Link>
            <Link
              to="/submission"
              className="flex items-center gap-2 text-sm transition-colors"
              style={{ color: "var(--accent)" }}
            >
              前往征稿
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </ScrollReveal>
      </div>
    </div>
  );
}
