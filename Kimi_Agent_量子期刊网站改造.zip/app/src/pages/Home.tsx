import { Link } from "react-router";
import { ArrowRight, Compass, Scroll, FolderArchive, MessageSquare } from "lucide-react";
import { ScrollReveal } from "@/components/ScrollReveal";
import { motion } from "framer-motion";

const sections = [
  {
    number: "01",
    title: "前沿与方法",
    path: "/frontiers",
    description: "术语约定、框架搭建、证据级别。写作也按标准来。",
    icon: Compass,
  },
  {
    number: "02",
    title: "传统与经验",
    path: "/tradition",
    description: "经验要落到细节。传统要说清合理性。门径要写出步骤。",
    icon: Scroll,
  },
  {
    number: "03",
    title: "田野与档案",
    path: "/field-archive",
    description: "现场与文本对照写。编号、来源、日期、地点。让证据站住。",
    icon: FolderArchive,
  },
  {
    number: "04",
    title: "对话与争鸣",
    path: "/dialogue",
    description: "争论要拆类型：事实、价值、策略。留余地，但不放弃判断。",
    icon: MessageSquare,
  },
];

const readingGuide = [
  {
    label: "想方法",
    text: "先去",
    link: { to: "/frontiers", text: "前沿与方法" },
    suffix: "，建立你的复用标准。",
  },
  {
    label: "想门径",
    text: "看",
    link: { to: "/tradition", text: "传统与经验" },
    suffix: "，把传承变成可执行步骤。",
  },
  {
    label: "想证据",
    text: "去",
    link: { to: "/field-archive", text: "田野与档案" },
    suffix: "，资料归档不再临时。",
  },
  {
    label: "想立场",
    text: "读",
    link: { to: "/dialogue", text: "对话与争鸣" },
    suffix: "，争论别把假设当事实。",
  },
];

export function Home() {
  return (
    <div>
      {/* Hero Section */}
      <section className="pt-24 md:pt-32 pb-16 md:pb-24">
        <div className="container-journal">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            {/* Left: Text */}
            <div className="order-2 lg:order-1">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
              >
                <p
                  className="text-caption mb-4"
                  style={{ color: "var(--muted)" }}
                >
                  <span style={{ fontFamily: '"Cormorant Garamond", serif', fontSize: "14px", fontStyle: "italic" }}>
                    Vol. 01 · 2026.05 · 创刊号
                  </span>
                </p>

                <div className="accent-line mb-6" />

                <h1
                  className="text-display font-bold mb-6"
                  style={{
                    fontFamily: '"Noto Serif SC", serif',
                    color: "var(--ink)",
                    wordBreak: "keep-all",
                  }}
                >
                  量子
                </h1>

                <h2
                  className="text-h2 mb-6"
                  style={{
                    fontFamily: '"Noto Serif SC", serif',
                    color: "var(--ink-light)",
                    wordBreak: "keep-all",
                  }}
                >
                  国际超心理与中国传统文化
                </h2>

                <div className="accent-line mb-6" style={{ width: "40px" }} />

                <p
                  className="text-body mb-8 max-w-lg"
                  style={{ color: "var(--ink-light)" }}
                >
                  给你一个清晰目录，让前沿与方法、传统与经验、田野与档案、对话与争鸣都有落点。
                  期刊式阅读的入口，从创刊号开始。
                </p>

                <div className="flex items-center gap-3">
                  <div
                    className="flex items-baseline gap-3 px-5 py-3 rounded-sm"
                    style={{ backgroundColor: "var(--accent-light)" }}
                  >
                    <span
                      className="text-4xl font-bold"
                      style={{
                        fontFamily: '"Cormorant Garamond", serif',
                        color: "var(--accent)",
                      }}
                    >
                      4
                    </span>
                    <span
                      className="text-sm"
                      style={{ color: "var(--ink-light)" }}
                    >
                      栏目 · 可选择阅读路径
                    </span>
                  </div>
                </div>
              </motion.div>
            </div>

            {/* Right: Cover Image */}
            <motion.div
              className="order-1 lg:order-2 flex justify-center"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <div
                className="relative overflow-hidden rounded-sm shadow-lg"
                style={{ maxWidth: "380px", width: "100%" }}
              >
                <img
                  src="/images/hero-cover.jpg"
                  alt="量子 Vol.01 创刊号封面"
                  className="w-full h-auto object-cover"
                  loading="eager"
                />
                <div
                  className="absolute inset-0 pointer-events-none"
                  style={{
                    boxShadow: "inset 0 0 0 1px rgba(0,0,0,0.08)",
                  }}
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Divider */}
      <div className="container-journal">
        <div className="divider-line" />
      </div>

      {/* Table of Contents */}
      <section className="section-spacing">
        <div className="container-journal">
          <ScrollReveal>
            <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4 mb-12">
              <div>
                <p
                  className="text-caption mb-2"
                  style={{ color: "var(--muted)" }}
                >
                  CONTENTS
                </p>
                <h2
                  className="text-h1"
                  style={{
                    fontFamily: '"Noto Serif SC", serif',
                    color: "var(--ink)",
                  }}
                >
                  本期目录
                </h2>
              </div>
              <p className="text-small" style={{ color: "var(--muted)" }}>
                四栏目 · 可选择阅读路径
              </p>
            </div>
          </ScrollReveal>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {sections.map((section, index) => (
              <ScrollReveal key={section.number} delay={index * 0.1}>
                <Link
                  to={section.path}
                  className="group block card-journal"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div
                      className="flex items-center justify-center w-10 h-10 rounded-sm"
                      style={{ backgroundColor: "var(--accent-light)" }}
                    >
                      <section.icon
                        className="w-5 h-5"
                        style={{ color: "var(--accent)" }}
                      />
                    </div>
                    <span
                      className="text-4xl font-semibold leading-none"
                      style={{
                        fontFamily: '"Cormorant Garamond", serif',
                        color: "var(--border-color)",
                      }}
                    >
                      {section.number}
                    </span>
                  </div>

                  <h3
                    className="text-h3 mb-3 group-hover:underline decoration-2 underline-offset-4"
                    style={{
                      fontFamily: '"Noto Serif SC", serif',
                      color: "var(--ink)",
                      textDecorationColor: "var(--accent)",
                    }}
                  >
                    {section.title}
                  </h3>

                  <p
                    className="text-small mb-4"
                    style={{ color: "var(--ink-light)" }}
                  >
                    {section.description}
                  </p>

                  <div className="flex items-center gap-1 text-sm transition-colors" style={{ color: "var(--accent)" }}>
                    <span>进入栏目</span>
                    <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                  </div>
                </Link>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* Divider */}
      <div className="container-journal">
        <div className="divider-line" />
      </div>

      {/* Reading Guide */}
      <section className="section-spacing" style={{ paddingBottom: "80px" }}>
        <div className="container-journal">
          <ScrollReveal>
            <div className="max-w-2xl">
              <p
                className="text-caption mb-2"
                style={{ color: "var(--muted)" }}
              >
                READING GUIDE
              </p>
              <h2
                className="text-h1 mb-10"
                style={{
                  fontFamily: '"Noto Serif SC", serif',
                  color: "var(--ink)",
                  wordBreak: "keep-all",
                }}
              >
                你关心什么，就从哪里读起
              </h2>
            </div>
          </ScrollReveal>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-6">
            {readingGuide.map((item, index) => (
              <ScrollReveal key={item.label} delay={index * 0.1}>
                <div
                  className="flex items-start gap-4 py-4"
                  style={{
                    borderBottom:
                      index < readingGuide.length - 1
                        ? "1px dashed var(--border-color)"
                        : "none",
                  }}
                >
                  <span
                    className="shrink-0 px-3 py-1 text-xs font-medium rounded-sm"
                    style={{
                      backgroundColor: "var(--accent-light)",
                      color: "var(--accent)",
                    }}
                  >
                    {item.label}
                  </span>
                  <p className="text-body" style={{ color: "var(--ink-light)" }}>
                    {item.text}
                    <Link
                      to={item.link.to}
                      className="font-medium underline underline-offset-4 transition-colors"
                      style={{
                        color: "var(--ink)",
                        textDecorationColor: "var(--accent)",
                      }}
                    >
                      {item.link.text}
                    </Link>
                    {item.suffix}
                  </p>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
