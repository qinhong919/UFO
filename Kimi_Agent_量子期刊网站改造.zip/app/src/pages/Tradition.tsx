import { Link } from "react-router";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { ScrollReveal } from "@/components/ScrollReveal";
import { motion } from "framer-motion";

const cards = [
  {
    label: "细节",
    title: "经验落到细节",
    description:
      "不要只说某人很厉害。写出具体做了什么、在什么情境下、产生了什么结果。细节才是可传承的经验。",
  },
  {
    label: "合理性",
    title: "传统要说清合理性",
    description:
      "传统之所以能延续，背后有逻辑。不要停留在这是老祖宗传下来的。追问：为什么这样设计？解决了什么问题？",
  },
  {
    label: "步骤",
    title: "门径写出步骤",
    description:
      "传承的关键是把路径变成可执行的步骤。第一步做什么、第二步做什么、每一步的要点和注意事项。",
  },
];

const principles = [
  {
    num: "壹",
    title: "经验不是感觉",
    desc: "经验是可重复的操作序列，不是个人感受。把感性认识转化为理性表述。",
  },
  {
    num: "贰",
    title: "传统不是教条",
    desc: "传统是前人的解决方案，但环境会变。理解其背后的原理，才能在新情境中灵活运用。",
  },
  {
    num: "叁",
    title: "门径不是捷径",
    desc: "真正的门径是少走弯路，不是不走。每一步都有其必要性，跳过步骤就是跳过理解。",
  },
];

export function Tradition() {
  return (
    <div className="pt-24 md:pt-32">
      <div className="container-journal">
        {/* Hero */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-16"
        >
          <div className="accent-line mb-6" />
          <h1
            className="text-h1 mb-4"
            style={{
              fontFamily: '"Noto Serif SC", serif',
              color: "var(--ink)",
              wordBreak: "keep-all",
            }}
          >
            传统与经验
          </h1>
          <p
            className="text-h3 mb-8 font-sans-body font-normal"
            style={{ color: "var(--ink-light)", wordBreak: "keep-all" }}
          >
            传统不是守旧，是前人的解题思路。经验不是感觉，是可验证的操作路径。
          </p>
          <p className="text-body max-w-2xl" style={{ color: "var(--ink-light)" }}>
            经验要落到细节。传统要说清合理性。门径要写出步骤。
          </p>
        </motion.div>

        {/* Principles */}
        <ScrollReveal>
          <div className="mb-16">
            <h2
              className="text-h3 mb-8"
              style={{
                fontFamily: '"Noto Serif SC", serif',
                color: "var(--ink)",
              }}
            >
              三条原则
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {principles.map((p, i) => (
                <ScrollReveal key={p.num} delay={i * 0.1}>
                  <div className="card-journal">
                    <span
                      className="text-2xl font-bold block mb-3"
                      style={{
                        fontFamily: '"Noto Serif SC", serif',
                        color: "var(--accent)",
                      }}
                    >
                      {p.num}
                    </span>
                    <h3
                      className="text-h3 mb-2"
                      style={{ fontFamily: '"Noto Serif SC", serif' }}
                    >
                      {p.title}
                    </h3>
                    <p
                      className="text-small"
                      style={{ color: "var(--ink-light)" }}
                    >
                      {p.desc}
                    </p>
                  </div>
                </ScrollReveal>
              ))}
            </div>
          </div>
        </ScrollReveal>

        {/* Cards */}
        <ScrollReveal>
          <div className="mb-16">
            <div className="flex items-baseline justify-between mb-8">
              <h2
                className="text-h3"
                style={{
                  fontFamily: '"Noto Serif SC", serif',
                  color: "var(--ink)",
                }}
              >
                写作要点
              </h2>
              <span
                className="text-caption"
                style={{ color: "var(--muted)" }}
              >
                三个方向
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {cards.map((card, i) => (
                <ScrollReveal key={card.label} delay={i * 0.1}>
                  <div className="card-journal">
                    <span
                      className="text-caption font-medium tracking-widest block mb-3"
                      style={{ color: "var(--accent)" }}
                    >
                      {card.label}
                    </span>
                    <h3
                      className="text-h3 mb-3"
                      style={{
                        fontFamily: '"Noto Serif SC", serif',
                        color: "var(--ink)",
                      }}
                    >
                      {card.title}
                    </h3>
                    <p
                      className="text-small leading-relaxed"
                      style={{ color: "var(--ink-light)" }}
                    >
                      {card.description}
                    </p>
                  </div>
                </ScrollReveal>
              ))}
            </div>
          </div>
        </ScrollReveal>

        {/* Bottom Navigation */}
        <ScrollReveal>
          <div
            className="flex items-center justify-between py-8 mb-8"
            style={{ borderTop: "1px solid var(--border-color)" }}
          >
            <Link
              to="/frontiers"
              className="flex items-center gap-2 text-sm transition-colors"
              style={{ color: "var(--ink-light)" }}
            >
              <ArrowLeft className="w-4 h-4" />
              上一栏目：前沿与方法
            </Link>
            <Link
              to="/field-archive"
              className="flex items-center gap-2 text-sm transition-colors"
              style={{ color: "var(--accent)" }}
            >
              下一栏目：田野与档案
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </ScrollReveal>
      </div>
    </div>
  );
}
