import { Link } from "react-router";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { ScrollReveal } from "@/components/ScrollReveal";
import { motion } from "framer-motion";

const cards = [
  {
    label: "CHECK",
    title: "你是在讲什么",
    description:
      "研究对象不清晰，后面都漂。起码写一句：我在处理什么现象。先把自己要处理的问题边界画出来，再谈方法。",
  },
  {
    label: "RISK",
    title: "别把假设当事实",
    description:
      "假设可以，但必须标注来源、说明理由。否则结论站不住。区分清楚哪些是观察、哪些是推论、哪些是猜测。",
  },
  {
    label: "MOVE",
    title: "把行动写出来",
    description:
      "建议要具体，像接下来做一件事就够了。模糊的呼吁没人能执行。写出可验证的下一步行动。",
  },
];

const standards = [
  {
    step: "1",
    title: "术语先约定",
    desc: "写清你用的词在此处是什么意思，别让读者猜。",
  },
  {
    step: "2",
    title: "问题先归类",
    desc: "是事实判断、价值判断，还是策略选择。",
  },
  {
    step: "3",
    title: "证据先整理",
    desc: "资料从哪来，可信度哪一级，遗漏承认。",
  },
];

export function Frontiers() {
  return (
    <div className="pt-24 md:pt-32">
      <div className="container-journal">
        {/* Hero */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-16"
        >
          <div className="accent-line mb-6" />
          <h1
            className="text-h1 mb-4"
            style={{
              fontFamily: '"Noto Serif SC", serif',
              color: "var(--ink)",
              wordBreak: "keep-all",
            }}
          >
            前沿与方法
          </h1>
          <p
            className="text-h3 mb-8 font-sans-body font-normal"
            style={{ color: "var(--ink-light)", wordBreak: "keep-all" }}
          >
            你要一个"可复用"的写作和研究标准。框架、概念、证据、论证——这四件事总不会错。
          </p>
          <p className="text-body max-w-2xl" style={{ color: "var(--ink-light)" }}>
            术语约定、框架搭建、证据级别。写作也按标准来。
          </p>
        </motion.div>

        {/* Standards */}
        <ScrollReveal>
          <div className="mb-16">
            <h2
              className="text-h3 mb-8"
              style={{
                fontFamily: '"Noto Serif SC", serif',
                color: "var(--ink)",
              }}
            >
              三项标准
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {standards.map((s, i) => (
                <ScrollReveal key={s.step} delay={i * 0.1}>
                  <div className="card-journal">
                    <span
                      className="text-3xl font-bold block mb-3"
                      style={{
                        fontFamily: '"Cormorant Garamond", serif',
                        color: "var(--accent)",
                      }}
                    >
                      {s.step}
                    </span>
                    <h3
                      className="text-h3 mb-2"
                      style={{ fontFamily: '"Noto Serif SC", serif' }}
                    >
                      {s.title}
                    </h3>
                    <p
                      className="text-small"
                      style={{ color: "var(--ink-light)" }}
                    >
                      {s.desc}
                    </p>
                  </div>
                </ScrollReveal>
              ))}
            </div>
          </div>
        </ScrollReveal>

        {/* Cards */}
        <ScrollReveal>
          <div className="mb-16">
            <div className="flex items-baseline justify-between mb-8">
              <h2
                className="text-h3"
                style={{
                  fontFamily: '"Noto Serif SC", serif',
                  color: "var(--ink)",
                }}
              >
                备忘
              </h2>
              <span
                className="text-caption"
                style={{ color: "var(--muted)" }}
              >
                出结论之前
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {cards.map((card, i) => (
                <ScrollReveal key={card.label} delay={i * 0.1}>
                  <div className="card-journal">
                    <span
                      className="text-caption font-medium tracking-widest block mb-3"
                      style={{ color: "var(--accent)" }}
                    >
                      {card.label}
                    </span>
                    <h3
                      className="text-h3 mb-3"
                      style={{
                        fontFamily: '"Noto Serif SC", serif',
                        color: "var(--ink)",
                      }}
                    >
                      {card.title}
                    </h3>
                    <p
                      className="text-small leading-relaxed"
                      style={{ color: "var(--ink-light)" }}
                    >
                      {card.description}
                    </p>
                  </div>
                </ScrollReveal>
              ))}
            </div>
          </div>
        </ScrollReveal>

        {/* Bottom Navigation */}
        <ScrollReveal>
          <div
            className="flex items-center justify-between py-8 mb-8"
            style={{ borderTop: "1px solid var(--border-color)" }}
          >
            <Link
              to="/"
              className="flex items-center gap-2 text-sm transition-colors"
              style={{ color: "var(--ink-light)" }}
            >
              <ArrowLeft className="w-4 h-4" />
              返回目录
            </Link>
            <Link
              to="/tradition"
              className="flex items-center gap-2 text-sm transition-colors"
              style={{ color: "var(--accent)" }}
            >
              下一栏目：传统与经验
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </ScrollReveal>
      </div>
    </div>
  );
}
