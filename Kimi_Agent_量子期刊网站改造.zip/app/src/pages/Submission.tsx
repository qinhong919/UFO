import { Link } from "react-router";
import { ArrowLeft, Send, CheckCircle } from "lucide-react";
import { ScrollReveal } from "@/components/ScrollReveal";
import { motion } from "framer-motion";

const requirements = [
  {
    title: "收稿范围",
    items: [
      "国际超心理学（parapsychology）相关研究、综述与评论",
      "中国传统文化的现代阐释与经验总结",
      "超心理现象与中国传统哲学、修炼体系的交叉研究",
      "方法论探讨：如何科学地研究超常经验",
      "田野调查、个案研究与档案整理",
    ],
  },
  {
    title: "写作标准",
    items: [
      "术语先约定：文中使用的核心概念需给出明确定义",
      "问题先归类：说明研究属于事实判断、价值判断还是策略选择",
      "证据先整理：标注资料来源、可信度级别、可能遗漏",
      "框架先搭建：给出清晰的研究框架和论证结构",
    ],
  },
  {
    title: "格式要求",
    items: [
      "字数：3000-15000 字为宜",
      "摘要：200-300 字中英文摘要",
      "关键词：3-5 个",
      "引用格式：APA 或 GB/T 7714",
      "可附图表、附录和补充材料",
    ],
  },
];

const process = [
  { step: "1", title: "投稿", desc: "发送稿件至编辑部邮箱" },
  { step: "2", title: "初审", desc: "7-14 个工作日内回复初审意见" },
  { step: "3", title: "同行评议", desc: "通过初审后进入双盲评审" },
  { step: "4", title: "录用", desc: "评审通过后安排刊发" },
];

export function Submission() {
  return (
    <div className="pt-24 md:pt-32">
      <div className="container-journal">
        {/* Hero */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-16"
        >
          <div className="accent-line mb-6" />
          <h1
            className="text-h1 mb-4"
            style={{
              fontFamily: '"Noto Serif SC", serif',
              color: "var(--ink)",
              wordBreak: "keep-all",
            }}
          >
            征稿
          </h1>
          <p
            className="text-h3 mb-8 font-sans-body font-normal"
            style={{ color: "var(--ink-light)", wordBreak: "keep-all" }}
          >
            可以发理论也可以发案例，但要建立加工结构，别让头脑的飞机在上面跑。
          </p>
          <p className="text-body max-w-2xl" style={{ color: "var(--ink-light)" }}>
            量子期刊接受原创研究、综述文章、方法论探讨和田野报告。
            我们期待严谨的思考和清晰的表达。
          </p>
        </motion.div>

        {/* Requirements */}
        <ScrollReveal>
          <div className="mb-16">
            <h2
              className="text-h3 mb-8"
              style={{
                fontFamily: '"Noto Serif SC", serif',
                color: "var(--ink)",
              }}
            >
              投稿要求
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {requirements.map((req, i) => (
                <ScrollReveal key={req.title} delay={i * 0.1}>
                  <div className="card-journal">
                    <h3
                      className="text-h3 mb-4"
                      style={{
                        fontFamily: '"Noto Serif SC", serif',
                        color: "var(--ink)",
                      }}
                    >
                      {req.title}
                    </h3>
                    <ul className="space-y-3">
                      {req.items.map((item, j) => (
                        <li
                          key={j}
                          className="flex items-start gap-2 text-small"
                          style={{ color: "var(--ink-light)" }}
                        >
                          <CheckCircle
                            className="w-4 h-4 shrink-0 mt-0.5"
                            style={{ color: "var(--accent)" }}
                          />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </ScrollReveal>
              ))}
            </div>
          </div>
        </ScrollReveal>

        {/* Process */}
        <ScrollReveal>
          <div className="mb-16">
            <h2
              className="text-h3 mb-8"
              style={{
                fontFamily: '"Noto Serif SC", serif',
                color: "var(--ink)",
              }}
            >
              审稿流程
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
              {process.map((p, i) => (
                <ScrollReveal key={p.step} delay={i * 0.1}>
                  <div className="text-center">
                    <span
                      className="text-4xl font-bold block mb-3"
                      style={{
                        fontFamily: '"Cormorant Garamond", serif',
                        color: "var(--accent)",
                      }}
                    >
                      {p.step}
                    </span>
                    <h3
                      className="text-h3 mb-1"
                      style={{
                        fontFamily: '"Noto Serif SC", serif',
                        color: "var(--ink)",
                      }}
                    >
                      {p.title}
                    </h3>
                    <p
                      className="text-small"
                      style={{ color: "var(--ink-light)" }}
                    >
                      {p.desc}
                    </p>
                    {i < process.length - 1 && (
                      <div
                        className="hidden md:block absolute top-8 -right-3 w-6 h-px"
                        style={{ backgroundColor: "var(--border-color)" }}
                      />
                    )}
                  </div>
                </ScrollReveal>
              ))}
            </div>
          </div>
        </ScrollReveal>

        {/* Contact CTA */}
        <ScrollReveal>
          <div
            className="mb-16 p-8 md:p-12 rounded-sm text-center"
            style={{
              backgroundColor: "var(--accent-light)",
              border: "1px solid rgba(193, 91, 63, 0.15)",
            }}
          >
            <Send
              className="w-8 h-8 mx-auto mb-4"
              style={{ color: "var(--accent)" }}
            />
            <h2
              className="text-h2 mb-3"
              style={{
                fontFamily: '"Noto Serif SC", serif',
                color: "var(--ink)",
              }}
            >
              开始投稿
            </h2>
            <p
              className="text-body mb-6 max-w-lg mx-auto"
              style={{ color: "var(--ink-light)" }}
            >
              请将稿件发送至编辑部邮箱，邮件主题请注明「投稿-栏目名-文章标题」。
              我们将在收到稿件后 7-14 个工作日内回复。
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <a
                href="mailto:submission@quantum-journal.org"
                className="inline-flex items-center gap-2 px-6 py-3 text-sm font-medium rounded-sm transition-colors"
                style={{
                  backgroundColor: "var(--accent)",
                  color: "white",
                }}
              >
                <Send className="w-4 h-4" />
                submission@quantum-journal.org
              </a>
            </div>
          </div>
        </ScrollReveal>

        {/* Bottom Navigation */}
        <ScrollReveal>
          <div
            className="flex items-center py-8 mb-8"
            style={{ borderTop: "1px solid var(--border-color)" }}
          >
            <Link
              to="/dialogue"
              className="flex items-center gap-2 text-sm transition-colors"
              style={{ color: "var(--ink-light)" }}
            >
              <ArrowLeft className="w-4 h-4" />
              上一栏目：对话与争鸣
            </Link>
          </div>
        </ScrollReveal>
      </div>
    </div>
  );
}
