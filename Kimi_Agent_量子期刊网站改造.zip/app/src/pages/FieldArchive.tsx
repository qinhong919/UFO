import { Link } from "react-router";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { ScrollReveal } from "@/components/ScrollReveal";
import { motion } from "framer-motion";

const cards = [
  {
    label: "记录",
    title: "现场与文本对照写",
    description:
      "田野笔记不是日记。要写清楚你看到了什么、听到了什么，以及你如何理解这些观察。与文献记录对照，找出差异和印证。",
  },
  {
    label: "编号",
    title: "编号、来源、日期、地点",
    description:
      "每一条资料都要有编号体系。谁说的、什么时候、在哪里。没有来源的信息不能作为证据使用。",
  },
  {
    label: "归档",
    title: "让证据站住",
    description:
      "资料归档不是收集完了放着。要分类、要标注、要建立索引。当别人质疑时，你能快速找到原始出处。",
  },
];

const checklist = [
  { item: "资料编号是否连续可追溯？", detail: "建立从采集到归档的完整编号链" },
  { item: "来源信息是否完整记录？", detail: "包括时间、地点、受访者背景、采集方式" },
  { item: "文本与现场是否交叉验证？", detail: "不要只依赖单一渠道的信息" },
  { item: "敏感信息是否脱敏处理？", detail: "保护受访者隐私是基本伦理" },
  { item: "归档格式是否统一规范？", detail: "确保他人能理解和使用你的资料" },
];

export function FieldArchive() {
  return (
    <div className="pt-24 md:pt-32">
      <div className="container-journal">
        {/* Hero */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-16"
        >
          <div className="accent-line mb-6" />
          <h1
            className="text-h1 mb-4"
            style={{
              fontFamily: '"Noto Serif SC", serif',
              color: "var(--ink)",
              wordBreak: "keep-all",
            }}
          >
            田野与档案
          </h1>
          <p
            className="text-h3 mb-8 font-sans-body font-normal"
            style={{ color: "var(--ink-light)", wordBreak: "keep-all" }}
          >
            田野不是旅游，档案不是收藏。两者都是证据工作，要求可追溯、可验证、可引用。
          </p>
          <p className="text-body max-w-2xl" style={{ color: "var(--ink-light)" }}>
            现场与文本对照写。编号、来源、日期、地点。让证据站住。
          </p>
        </motion.div>

        {/* Checklist */}
        <ScrollReveal>
          <div className="mb-16">
            <h2
              className="text-h3 mb-8"
              style={{
                fontFamily: '"Noto Serif SC", serif',
                color: "var(--ink)",
              }}
            >
              田野档案自查清单
            </h2>
            <div className="space-y-0">
              {checklist.map((c, i) => (
                <ScrollReveal key={i} delay={i * 0.05}>
                  <div
                    className="flex items-start gap-4 py-5"
                    style={{
                      borderBottom: "1px solid var(--border-color)",
                    }}
                  >
                    <span
                      className="shrink-0 w-6 h-6 flex items-center justify-center rounded-sm text-xs font-bold mt-0.5"
                      style={{
                        backgroundColor: "var(--accent-light)",
                        color: "var(--accent)",
                      }}
                    >
                      {i + 1}
                    </span>
                    <div>
                      <p
                        className="text-body font-medium mb-1"
                        style={{ color: "var(--ink)" }}
                      >
                        {c.item}
                      </p>
                      <p
                        className="text-small"
                        style={{ color: "var(--muted)" }}
                      >
                        {c.detail}
                      </p>
                    </div>
                  </div>
                </ScrollReveal>
              ))}
            </div>
          </div>
        </ScrollReveal>

        {/* Cards */}
        <ScrollReveal>
          <div className="mb-16">
            <div className="flex items-baseline justify-between mb-8">
              <h2
                className="text-h3"
                style={{
                  fontFamily: '"Noto Serif SC", serif',
                  color: "var(--ink)",
                }}
              >
                三个要点
              </h2>
              <span
                className="text-caption"
                style={{ color: "var(--muted)" }}
              >
                实操指南
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {cards.map((card, i) => (
                <ScrollReveal key={card.label} delay={i * 0.1}>
                  <div className="card-journal">
                    <span
                      className="text-caption font-medium tracking-widest block mb-3"
                      style={{ color: "var(--accent)" }}
                    >
                      {card.label}
                    </span>
                    <h3
                      className="text-h3 mb-3"
                      style={{
                        fontFamily: '"Noto Serif SC", serif',
                        color: "var(--ink)",
                      }}
                    >
                      {card.title}
                    </h3>
                    <p
                      className="text-small leading-relaxed"
                      style={{ color: "var(--ink-light)" }}
                    >
                      {card.description}
                    </p>
                  </div>
                </ScrollReveal>
              ))}
            </div>
          </div>
        </ScrollReveal>

        {/* Bottom Navigation */}
        <ScrollReveal>
          <div
            className="flex items-center justify-between py-8 mb-8"
            style={{ borderTop: "1px solid var(--border-color)" }}
          >
            <Link
              to="/tradition"
              className="flex items-center gap-2 text-sm transition-colors"
              style={{ color: "var(--ink-light)" }}
            >
              <ArrowLeft className="w-4 h-4" />
              上一栏目：传统与经验
            </Link>
            <Link
              to="/dialogue"
              className="flex items-center gap-2 text-sm transition-colors"
              style={{ color: "var(--accent)" }}
            >
              下一栏目：对话与争鸣
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </ScrollReveal>
      </div>
    </div>
  );
}
