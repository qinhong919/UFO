import { Routes, Route, useLocation } from "react-router";
import { AnimatePresence } from "framer-motion";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { PageTransition } from "@/components/PageTransition";
import { Home } from "@/pages/Home";
import { Frontiers } from "@/pages/Frontiers";
import { Tradition } from "@/pages/Tradition";
import { FieldArchive } from "@/pages/FieldArchive";
import { Dialogue } from "@/pages/Dialogue";
import { Submission } from "@/pages/Submission";
import { useEffect } from "react";

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

export default function App() {
  const location = useLocation();

  return (
    <div className="min-h-[100dvh] flex flex-col">
      <ScrollToTop />
      <Navbar />
      <main className="flex-1">
        <AnimatePresence mode="wait">
          <PageTransition key={location.pathname}>
            <Routes location={location}>
              <Route path="/" element={<Home />} />
              <Route path="/frontiers" element={<Frontiers />} />
              <Route path="/tradition" element={<Tradition />} />
              <Route path="/field-archive" element={<FieldArchive />} />
              <Route path="/dialogue" element={<Dialogue />} />
              <Route path="/submission" element={<Submission />} />
            </Routes>
          </PageTransition>
        </AnimatePresence>
      </main>
      <Footer />
    </div>
  );
}
